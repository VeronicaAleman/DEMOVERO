package com.jonareas.persistence.model.dao

import androidx.room.*
import androidx.room.OnConflictStrategy.REPLACE
import com.jonareas.persistence.model.entities.User

@Dao
interface UserDao {

    @Insert(onConflict = REPLACE)
    suspend fun insert(user: User)
    // Inserts several users
    @Insert(onConflict = REPLACE)
    suspend fun insert(vararg user: User)

    @Query("SELECT * FROM Users")
    suspend fun getAll() : List<User>

    @Query("SELECT * FROM Users WHERE userId = :id")
    suspend fun getById(id : Int) : User

    @Update
    suspend fun update(user : User)

    @Delete
    suspend fun delete(user : User)
    // Insert severals users
    @Delete
    suspend fun delete(vararg user : User)


}