package com.jonareas.android.transactions.data.repository


import com.jonareas.persistence.model.entities.User
import kotlinx.coroutines.flow.Flow

interface UserRepositoy {
    suspend fun  insertUser(user: User)
    suspend fun  getAll(): Flow<List<User>>
    suspend fun  getbyId(id:Int): User
    suspend fun UpdateUser(User: User)
    suspend fun  deleteUser(User: User)
}