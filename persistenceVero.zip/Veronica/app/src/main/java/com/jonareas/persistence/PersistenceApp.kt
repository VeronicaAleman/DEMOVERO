package com.jonareas.persistence

import android.app.Application
import com.jonareas.persistence.model.PersistenceDatabase

class PersistenceApp : Application() {

    companion object {
        lateinit var application : Application private set

        val database by lazy {
            PersistenceDatabase.getInstance(application)
        }
    }

    override fun onCreate() {
        super.onCreate()
        application = this
    }

}