package com.jonareas.persistence.Repository
import com.jonareas.android.transactions.data.repository.UserRepositoy
import com.jonareas.persistence.model.entities.User
import kotlinx.coroutines.flow.Flow


class UserRepositoryImpl private constructor(
    private val user: User

): UserRepositoy {

    companion object {
        @Volatile
        private var INSTANCE: UserRepositoy? = null
        private fun createInstance(): UserRepositoy =
            UserRepositoryImpl()

        operator fun invoke(): UserRepositoy = INSTANCE ?: synchronized(this) {
            createInstance()
        }.also { INSTANCE = it }
    }

    override suspend fun insertUser(user: User) {







    }

    override suspend fun getAll(): Flow<List<User>> {
        TODO("Not yet implemented")
    }

    override suspend fun getbyId(id: Int): User {
        TODO("Not yet implemented")
    }

    override suspend fun UpdateUser(User: User) {
        TODO("Not yet implemented")
    }

    override suspend fun deleteUser(User: User) {
        TODO("Not yet implemented")
    }
}