package com.jonareas.persistence.model

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.jonareas.persistence.model.entities.User

@Database(entities = [User::class], version = 1)
abstract class PersistenceDatabase : RoomDatabase() {

    companion object {

        @Volatile
        private var INSTANCE : PersistenceDatabase? = null

        private fun buildInstance(context : Context) = Room.databaseBuilder(context,
            PersistenceDatabase::class.java,
            "persistence")
            .fallbackToDestructiveMigration()
            .build()

        fun getInstance(context : Context) : PersistenceDatabase =
            INSTANCE ?: synchronized(this) {
                buildInstance(context)
            }.also { INSTANCE = it }


    }



}