package com.jonareas.persistence.ViewModel

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope


import com.jonareas.android.transactions.data.repository.UserRepositoy
import com.jonareas.persistence.Repository.UserRepositoryImpl
import com.jonareas.persistence.model.entities.User

class MainViewModel(private val userRepositoy: UserRepositoy = UserRepositoryImpl.invoke()): ViewModel() {
    private var _user = MutableLiveData<List<User>>()
    var user : LiveData<List<User>> = _user
    init {
        getUser()
    }

    private fun getUser() {
        viewModelScope
    }
}